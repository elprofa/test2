import React, {Component} from 'react';

class Satisfaction extends Component
{
    render(){
        return (
            <div className="row" id="rowSatisfaction">
                <div className="col-lg-12">
                    <h1 className="h1Satisfaction">Skooli ensured your satisfaction</h1>
                </div>
                <div className="col-lg-3">
                    <div className="card" id="card1">
                        <div className="card-body">
                            <span className="fa fa-user" id="spanSatisfaction"></span>
                            <h5 className="card-title">Card title</h5>
                            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                    </div>
                </div>
                <div className="col-lg-3">
                    <div className="card" id="card1">
                        <div className="card-body">
                            <span className="fa fa-user" id="spanSatisfaction"></span>
                            <h5 className="card-title">Card title</h5>
                            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                    </div>
                </div>
                <div className="col-lg-3">
                    <div className="card" id="card1">
                        <div className="card-body">
                            <span className="fa fa-user" id="spanSatisfaction"></span>
                            <h5 className="card-title">Card title</h5>
                            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                    </div>
                </div>
                <div className="col-lg-3">
                    <div className="card" id="card1">
                        <div className="card-body">
                            <span className="fa fa-user" id="spanSatisfaction"></span>
                            <h5 className="card-title">Card title</h5>
                            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}


export default Satisfaction